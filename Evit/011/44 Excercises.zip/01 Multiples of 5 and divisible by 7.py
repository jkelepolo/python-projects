# Jothan Kelepolo
# 011.1
# 9/8/20

numList = []

for i in range(1500,2700):
    if i % 7 == 0 and i % 5 == 0:
        numList.append(i)

print(numList)
