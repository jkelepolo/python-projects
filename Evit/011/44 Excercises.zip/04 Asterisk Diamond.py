# Jothan Kelepolo
# 011.1
# 9/8/20


for i in range(0,10):
    print("")
    for j in range(0,i):
        print("*", end = "")


for i in range(10,0,-1):
    print("")
    for j in range(0,i):
        print("*", end = "")
