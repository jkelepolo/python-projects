# Jothan Kelepolo
# 011.1
# 9/8/20

skip = [3,6]

for i in range(0,11):
    if i in skip:
        continue
    print(i,end=' ')
print("\n")
