# Jothan Kelepolo
# 011.1
# 9/8/20

for i in range(10):
    print(str(i) * i)
	
