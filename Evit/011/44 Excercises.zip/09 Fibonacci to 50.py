# Jothan Kelepolo
# 011.1
# 9/8/20

x,y=0,1

while y<50:
    print(y)
    x,y = y,x+y
